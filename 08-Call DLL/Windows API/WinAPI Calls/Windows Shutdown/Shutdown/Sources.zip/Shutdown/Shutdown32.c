#include <windows.h>
#include <winnt.h>

#include "Shutdown32.h"

DWORD WINAPI LVShutdown (BOOL bForceCloseApplications, int RestartMode)
{
	BOOL bIsNT;
	UINT flags;

	HANDLE hToken; 
	TOKEN_PRIVILEGES tkp; 
 
	if (GetVersion() < 0x80000000)                // Windows NT/2000
		bIsNT = TRUE;
	else
		bIsNT = FALSE;


	if (bIsNT)
	{
		// Get a token for this process. 
 
		if (!OpenProcessToken(GetCurrentProcess(), 
				TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
			return (6);
 
		// Get the LUID for the shutdown privilege. 
 
		LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, 
				&tkp.Privileges[0].Luid); 
 
		tkp.PrivilegeCount = 1;  // one privilege to set    
		tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 
 
		// Get the shutdown privilege for this process. 
 
		AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
				(PTOKEN_PRIVILEGES)NULL, 0); 
 
		// Cannot test the return value of AdjustTokenPrivileges. 
 
		if (GetLastError() != ERROR_SUCCESS) 
			return (7);
	}
	// Shut down the system. 

	switch (RestartMode)
	{
	case 0: // power off
		flags = EWX_POWEROFF;
		break;
	case 1: // shutdown
		flags = EWX_SHUTDOWN;
		break;
	case 2: // reboot
		flags = EWX_REBOOT;
		break;
	default:
		flags = EWX_POWEROFF;
	}

	if (bForceCloseApplications)
		flags |= EWX_FORCE;

	if (!ExitWindowsEx(flags, 0))
		return GetLastError();
	else
		return 0;
}


