#ifndef _Shutdown32_INCLUDED_
#define _Shutdown32_INCLUDED_

DWORD WINAPI LVShutdown (BOOL bForceCloseApplications, int RestartMode)

#endif
